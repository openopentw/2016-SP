# b04902053 鄭淵仁 #

#      SP hw3      #


# How to compile my program

	Just run 'make'.

# How to run my server

	Type as follow:
	$ ./server [port] [logname]

	For example, type this
	$ ./server 12345 tmp.log

# What functionality had you done, and anything you have done besides the
basic functionality

	All as the spec says.
